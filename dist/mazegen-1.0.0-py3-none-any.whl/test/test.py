from mazegen.maze import Maze

maze = Maze(entry=(-2, 2))
maze.generate()
print(maze.entry)
print(maze.exit)
